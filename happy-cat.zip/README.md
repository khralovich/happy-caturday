# happy-caturday

This Chrome extension shows a random cat picture every time you open a new tab =^._.^= ∫

Made using [TheCatApi](https://docs.thecatapi.com/#thecatapi--developer-experience) and with help of my cat Arch.

![Arch](https://github.com/khralovich/happy-caturday/blob/main/img/preview.png)


